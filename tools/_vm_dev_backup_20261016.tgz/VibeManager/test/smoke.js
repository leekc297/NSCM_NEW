const path = require('path'); const fs = require('fs');
// 가짜 프로젝트 루트: mnt 의 실제 폴더 구조를 쓴다
process.env.VM_ROOT = process.env.VM_ROOT || path.join(process.env.HOME, 'mnt', 'NSCM');
const ext = require('../extension.js'); const vscode = require('vscode');
const ctx = { extensionPath: path.join(__dirname, '..'), subscriptions: [], workspaceState: { _m: {}, get(k, d) { return this._m[k] ?? d; }, update(k, v) { this._m[k] = v; } } };
ext.activate(ctx);
const providers = Object.fromEntries(vscode._subs.filter(s => s[0].startsWith('vibeManager.') && s[1].getChildren).map(s => [s[0], s[1]]));
(async () => {
  for (const [id, p] of Object.entries(providers)) {
    const roots = await p.getChildren(); let n = roots.length, leaves = 0;
    for (const r of roots) { const kids = await p.getChildren(r); leaves += kids.length; }
    console.log(id, 'roots', n, 'leaves', leaves);
  }
  const cmds = Object.fromEntries(vscode._subs.filter(s => typeof s[1] === 'function').map(s => [s[0], s[1]]));
  await cmds['vibeManager.openDashboard'](); console.log('dashboard ok');
  await cmds['vibeManager.checkEnv'](); console.log('checkEnv ok');
  await cmds['vibeManager.gateReport'](); console.log('gateReport ok');
  await cmds['vibeManager.quickScreen'](); console.log('quickScreen ok');
  console.log('tasks executed', vscode._subs.filter(s => s[0] === 'task').length);
})().catch(e => { console.error('SMOKE FAIL', e); process.exit(1); });
