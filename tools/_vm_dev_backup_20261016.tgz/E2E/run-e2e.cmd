@echo off
REM E2E 일괄 (노트북): 의존성 설치확인 -> 계정/스펙 생성 -> 실행 -> 리포트
REM 사용: run-e2e.cmd [smoke|crud|auth|all] [화면ID ...]      (기본 smoke, 화면ID 없으면 Doc\gen 전체)
REM 선행: FE(http://localhost:3000) / BE(http://localhost:8080, profile local|dev — /sso/dev-login 활성) 기동
setlocal
cd /d %~dp0
set KIND=%1
if "%KIND%"=="" set KIND=smoke
set LOG=C:\Projects\NSCM\Doc\e2e\_run.log
if not exist C:\Projects\NSCM\Doc\e2e\results mkdir C:\Projects\NSCM\Doc\e2e\results
echo ==== %date% %time% run-e2e %* >> %LOG%
if not exist node_modules\@playwright (
  echo [설치] npm install + chromium ...
  call npm install --no-audit --no-fund >> %LOG% 2>&1
  call npx playwright install chromium >> %LOG% 2>&1
)
if not exist accounts.json python gen-accounts.py >> %LOG% 2>&1
shift
set IDS=
:loop
if not "%1"=="" ( set IDS=%IDS% %1 & shift & goto loop )
if "%IDS%"=="" ( node gen-e2e.js --all >> %LOG% 2>&1 ) else ( node gen-e2e.js %IDS% >> %LOG% 2>&1 )
curl -s -o nul -w "FE %%{http_code}\n" http://localhost:3000/ || echo [WARN] FE 미기동
curl -s -o nul -w "BE %%{http_code}\n" http://localhost:8080/sso/dev-login?id=_probe_ || echo [WARN] BE 미기동(또는 dev-login 비활성)
if /i "%KIND%"=="all" ( call npx playwright test >> %LOG% 2>&1 ) else ( call npx playwright test --grep @%KIND% >> %LOG% 2>&1 )
node report.js
echo 로그: %LOG%
endlocal
